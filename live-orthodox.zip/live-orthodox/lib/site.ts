export const SITE = {
  name: 'Live Orthodox',
  tagline:
    'A resource dedicated to Eastern Orthodox Christianity, philosophy, theology, and thoughtful responses to common objections.',
  description:
    'Live Orthodox is a modern Eastern Orthodox Christian philosophy and apologetics platform covering theology, philosophy, church history, biblical interpretation, and responses to common objections and alleged contradictions.',
  // Set this to your production URL before deploying (used for canonical URLs, sitemap, OG tags).
  url: 'https://example.github.io/live-orthodox',
  owner: 'Unified',
  twitterHandle: '@liveorthodox',
};

export const NAV_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/articles/', label: 'Articles' },
  { href: '/contradictions/', label: 'Contradictions' },
  { href: '/philosophy/', label: 'Philosophy' },
  { href: '/about/', label: 'About' },
];
