import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import readingTime from 'reading-time';
import type { Article, Contradiction } from '@/lib/types';

export type { Article, Contradiction } from '@/lib/types';
export { CATEGORIES, CONTRADICTION_TYPES } from '@/lib/types';

const ARTICLES_DIR = path.join(process.cwd(), 'content/articles');
const CONTRADICTIONS_DIR = path.join(process.cwd(), 'content/contradictions');

function readDir(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((f) => f.endsWith('.md'));
}

export function getAllArticles(): Article[] {
  const files = readDir(ARTICLES_DIR);
  const articles = files.map((filename) => {
    const slug = filename.replace(/\.md$/, '');
    const raw = fs.readFileSync(path.join(ARTICLES_DIR, filename), 'utf-8');
    const { data, content } = matter(raw);
    const stats = readingTime(content);
    return {
      slug,
      title: data.title ?? slug,
      description: data.description ?? '',
      author: data.author ?? 'Live Orthodox',
      date: data.date ?? '',
      category: data.category ?? 'Theology',
      tags: data.tags ?? [],
      featuredImage: data.featuredImage,
      readingTime: stats.text,
      featured: !!data.featured,
      content,
    } as Article;
  });
  return articles.sort((a, b) => (a.date < b.date ? 1 : -1));
}

export function getArticleBySlug(slug: string): Article | undefined {
  return getAllArticles().find((a) => a.slug === slug);
}

export function getAllArticleSlugs(): string[] {
  return readDir(ARTICLES_DIR).map((f) => f.replace(/\.md$/, ''));
}

export function getAllContradictions(): Contradiction[] {
  const files = readDir(CONTRADICTIONS_DIR);
  const items = files.map((filename) => {
    const slug = filename.replace(/\.md$/, '');
    const raw = fs.readFileSync(path.join(CONTRADICTIONS_DIR, filename), 'utf-8');
    const { data, content } = matter(raw);
    return {
      slug,
      title: data.title ?? slug,
      claim: data.claim ?? '',
      type: data.type ?? 'old-testament',
      verses: data.verses ?? [],
      summary: data.summary ?? '',
      date: data.date ?? '',
      content,
    } as Contradiction;
  });
  return items.sort((a, b) => (a.title > b.title ? 1 : -1));
}

export function getContradictionBySlug(slug: string): Contradiction | undefined {
  return getAllContradictions().find((c) => c.slug === slug);
}

export function getAllContradictionSlugs(): string[] {
  return readDir(CONTRADICTIONS_DIR).map((f) => f.replace(/\.md$/, ''));
}
