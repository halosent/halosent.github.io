export type Article = {
  slug: string;
  title: string;
  description: string;
  author: string;
  date: string;
  category: string;
  tags: string[];
  featuredImage?: string;
  readingTime: string;
  featured?: boolean;
  content: string;
};

export type Contradiction = {
  slug: string;
  title: string;
  claim: string;
  type: 'old-testament' | 'new-testament' | 'historical' | 'philosophical' | 'scientific';
  verses: string[];
  summary: string;
  content: string;
  date: string;
};

export const CATEGORIES = [
  'Biblical Contradictions',
  'Philosophy',
  'Theology',
  'Church Fathers',
  'Church History',
  'Ethics',
  'Science',
  'Apologetics',
];

export const CONTRADICTION_TYPES: { value: Contradiction['type']; label: string }[] = [
  { value: 'old-testament', label: 'Old Testament' },
  { value: 'new-testament', label: 'New Testament' },
  { value: 'historical', label: 'Historical Claims' },
  { value: 'philosophical', label: 'Philosophical Objections' },
  { value: 'scientific', label: 'Scientific Objections' },
];
