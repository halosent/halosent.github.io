---
title: "Two Creation Accounts in Genesis: A Real Contradiction?"
claim: "Genesis 1 and Genesis 2 present two different, conflicting orders of creation."
type: "old-testament"
verses: ["Genesis 1:1-2:3", "Genesis 2:4-25"]
summary: "Genesis 1 and 2 are complementary in genre and purpose, not competing chronological reports: the second account zooms in on humanity rather than re-narrating a sequence."
date: "2026-02-10"
---

## The Objection

Genesis 1 presents a six-day sequence culminating in the creation of humanity, male and female together, as the final act. Genesis 2 appears to narrate a different order: man is formed first, then vegetation, then animals, then woman. Critics argue the two chapters cannot both be straightforward chronological accounts of the same events.

## The Orthodox Response

### Different genre, different purpose

Orthodox and patristic exegesis, going back at least to St. John Chrysostom and St. Basil the Great, generally did not read Genesis 1 and 2 as two competing chronological logs meant to be reconciled hour by hour. Genesis 1 is a structured, liturgically patterned account organized around the theme of God bringing order out of formlessness, culminating in the Sabbath rest — its literary structure (days paired thematically, refrains, a clear crescendo) signals a theological composition, not a bare timestamped log.

Genesis 2 shifts genre and focus entirely. It is not a second, rival creation narrative but a close-up on the creation of humanity specifically, told from a different vantage point, in the same way a historical account might first give a broad overview of a war and then return to narrate one battle in intimate detail, without contradiction.

### The sequence issue is a translation and framing question, not a factual clash

Much of the apparent contradiction rests on how Genesis 2:19 is translated. The Hebrew verb form is ambiguous between a strict past tense ("God had formed") and a simple past ("God formed"), and many scholars, including within the Orthodox exegetical tradition, read it as a pluperfect: the animals mentioned in Genesis 2 were **already** formed (as Genesis 1 describes), and are simply being brought before Adam to be named at this point in the narrative, not created anew in a different order.

Even without this translation point, ancient Near Eastern narrative convention regularly narrates events out of strict chronological order to serve a thematic purpose — a convention modern readers, accustomed to strict chronological reporting, can miss.

### The purpose of the pairing

Read together, Genesis 1 establishes humanity's place within the whole created order — crowned as the image of God over creation. Genesis 2 turns to humanity's intimate, relational nature: formed from the earth, given purpose and companionship, and bound in covenant relationship with both God and the created world. Orthodox theology treats this pairing as intentional and complementary: cosmic scope followed by intimate detail, not two rival reports competing for factual priority.

## Philosophical and Theological Context

Orthodox theology has never demanded a rigidly literalist reading of Genesis 1–2 as its only legitimate interpretation. Figures such as St. Basil the Great in the *Hexaemeron* combined close attention to the text with awareness of figurative and theological dimensions, while later Fathers such as St. Gregory of Nyssa read parts of the creation narrative more allegorically still. The unifying Orthodox commitment is to the theological claims the text makes — that God freely created all that exists, that humanity bears His image, that creation is good — rather than to one single method of harmonizing chronological detail.

## Sources

- St. Basil the Great, *Hexaemeron*
- St. John Chrysostom, *Homilies on Genesis*
- John Walton, *The Lost World of Genesis One*, on ancient Near Eastern narrative conventions
