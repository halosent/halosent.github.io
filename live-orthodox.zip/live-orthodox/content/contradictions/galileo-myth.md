---
title: "Did the Church Suppress Science? The Galileo Affair Reconsidered"
claim: "The Galileo affair proves that Christianity is fundamentally opposed to science and has historically suppressed scientific progress."
type: "historical"
verses: []
summary: "The Galileo affair was a specific, complicated conflict involving politics, personalities, and unproven claims — not a representative clash between Christianity and science, and Orthodox Christianity was not party to it at all."
date: "2026-04-20"
---

## The Objection

The trial of Galileo Galilei by the Roman Inquisition in 1633 is frequently cited as decisive proof that Christianity, and religion generally, is inherently hostile to scientific inquiry — that the Church suppressed Galileo's heliocentrism purely out of dogmatic resistance to truth.

## The Orthodox Response

### A Roman Catholic institutional dispute, not an Orthodox one

It should first be noted plainly: the Galileo affair was a proceeding of the Roman Catholic Inquisition, an institutional and juridical structure with no equivalent in Eastern Orthodox Christianity, which has no comparable centralized magisterium or history of inquisitorial courts. Whatever judgment one reaches about the affair, it cannot be generalized into a claim about Christianity, or about the Orthodox Church specifically, without significant qualification.

### The historical record is more complicated than the popular version

Historians of science, including several who are not religious apologists, have long noted that the popular narrative — simple dogmatism versus simple truth-telling — misrepresents the episode in several ways:

Galileo did not yet possess conclusive proof of heliocentrism at the time of his condemnation. His strongest argument, based on the tides, was in fact mistaken, and the stellar parallax that would later confirm Earth's motion around the sun was not observed until the nineteenth century. Several of Galileo's own scientific contemporaries, including some who supported heliocentrism as a mathematical model, considered his physical proof incomplete.

The dispute was also entangled with politics and personality. Galileo had cultivated influential enemies, framed his arguments in a way that appeared (whether intended or not) to mock Pope Urban VIII personally in his *Dialogue Concerning the Two Chief World Systems*, and pressed for heliocentrism to be taught as established physical fact rather than a useful mathematical model, at a time when the evidence, by the standards of the day, did not yet fully warrant that certainty.

None of this is offered to claim the Inquisition's actions were justified — Galileo's house arrest and the suppression of his work were a genuine wrong, and many Roman Catholic scholars and clergy have said so directly, including formal expressions of regret from the Vatican in the twentieth century. The point is narrower: the affair was a specific, historically tangled conflict, not a clean demonstration of an inherent, structural war between "religion" and "science."

### The broader historical relationship between Christianity and science

The "warfare thesis" — the idea that Christianity and science have been in perpetual conflict throughout history — is regarded by most historians of science today as a serious oversimplification, originating largely from nineteenth-century polemical writers rather than careful historical research. Many founders of modern science, including Copernicus (a cleric), Kepler, Newton, and Mendel (an Augustinian friar), understood their scientific work as compatible with, or even motivated by, their religious convictions about an orderly, rational, divinely created universe worth investigating.

Byzantine and later Orthodox intellectual culture, for its part, preserved and transmitted classical scientific and philosophical texts through centuries when much of this material was lost in the West, and Orthodox monastic centers maintained scriptoria and schools that included natural philosophy alongside theology.

## Philosophical Context

Much of the intuitive force behind "religion versus science" narratives depends on treating both as competing explanations for the same kinds of questions. Orthodox theology, following its apophatic and patristic heritage, has generally distinguished the *kind* of questions science and theology ask — how the natural order operates, versus why there is an order at all and what it means — rather than treating them as rival explanations of the same phenomena.

## Sources

- Ronald Numbers (ed.), *Galileo Goes to Jail and Other Myths About Science and Religion*
- Maurice Finocchiaro, *The Galileo Affair: A Documentary History*
- Colin Russell, *Cross-Currents: Interactions Between Science and Faith*
