---
title: "The Problem of Evil: Can a Good and Powerful God Coexist With Suffering?"
claim: "If God is all-good and all-powerful, evil should not exist. Since evil exists, God either is not all-good, not all-powerful, or does not exist."
type: "philosophical"
verses: ["Genesis 3", "Job 1-42", "Romans 8:18-23"]
summary: "Orthodox theology distinguishes the logical and evidential forms of the problem, grounding its response in free will, the goodness of creation, and the cross rather than a tidy theoretical solution."
date: "2026-01-25"
---

## The Objection

Stated in its classical logical form: an all-good God would want to eliminate evil; an all-powerful God would be able to eliminate evil; evil exists; therefore no such God exists. A softer, evidential version argues that even if some evil is explicable, the sheer scale and apparent gratuitousness of suffering in the world counts as strong evidence against a good, all-powerful God.

## The Orthodox Response

### The logical problem is widely regarded as resolved

Since the mid-twentieth century, most philosophers of religion, including many atheist philosophers, have accepted that the strict logical version of the argument fails, because it requires an additional premise — that God has no morally sufficient reason for permitting evil — which is not self-evidently true and cannot simply be assumed. If it is even *possible* that God has a good reason for permitting some evil (such as preserving genuine creaturely freedom), the strict logical contradiction dissolves.

The more serious and enduring challenge is the evidential form: not whether evil and God are logically compatible, but whether the amount and kind of suffering in the world make God's existence improbable.

### Freedom as a genuine good with a genuine cost

Orthodox theology places heavy weight on the reality and value of creaturely freedom. Because love, by its nature, cannot be coerced, a world capable of genuine love and communion with God must also be a world capable of genuine refusal — and refusal has consequences that ripple outward. Much moral evil, on this account, is not a flaw in creation's design but the necessary shadow cast by the very freedom that makes love, virtue, and communion possible at all.

This does not, on its own, account for natural evil — disease, earthquakes, the suffering of animals — which is why Orthodox theology typically supplements it with a further claim.

### Creation itself as wounded, not merely the moral choices within it

Following St. Paul's language in Romans 8, that creation itself was "subjected to futility" and groans while awaiting redemption, Orthodox theology often treats the natural order as genuinely disordered by the fall — not merely the arena in which human sin plays out, but itself caught up in a real cosmic rupture. This resists treating natural evil as a separate philosophical puzzle requiring its own justification; it is part of the same wound that moral evil represents, affecting the whole created order rather than human choices alone.

### The refusal to offer a tidy theoretical resolution

It is worth being direct: Orthodox theology has generally resisted constructing a complete theoretical justification that would explain **every** instance of suffering — the "theodicy project" in its most ambitious form. The Book of Job is often read within Orthodoxy as instructive precisely because God's response to Job's suffering is not a philosophical explanation but a summons into a larger vision of the created order, met ultimately with Job's own admission that he had spoken of things beyond his understanding.

The decisive Orthodox response to evil is finally not a philosophical argument at all, but the cross and resurrection of Christ: a God who does not remain distant from suffering but enters fully into it, and who is believed to have the power to bring a good — resurrection — out of the worst evil history has produced, the death of the innocent Son of God. This does not explain away any particular instance of suffering, but it reframes the question from "why does a good God permit evil" to "what has this good God done about it," a shift Orthodox theology considers decisive.

## Philosophical Context

Contemporary philosophy of religion (Alvin Plantinga's free will defense, William Rowe's evidential formulations, and Marilyn McCord Adams's work on horrendous evils) continues to refine both sides of this debate. Orthodox theology draws selectively on this literature while remaining rooted in its own patristic and liturgical resources, particularly the theology of the cross and the eschatological hope of resurrection.

## Sources

- Alvin Plantinga, *God, Freedom, and Evil*
- St. Maximus the Confessor on the fall and the cosmic scope of redemption
- David Bentley Hart, *The Doors of the Sea*, written after the 2004 Indian Ocean tsunami
