---
title: "Did Judas Hang Himself or Fall Headlong? (Matthew 27 vs. Acts 1)"
claim: "Matthew says Judas hanged himself; Acts says he fell and burst open. These accounts cannot both be true."
type: "new-testament"
verses: ["Matthew 27:3-8", "Acts 1:16-19"]
summary: "The two accounts describe different moments and are not mutually exclusive: a hanging that led to a fall is a natural, not contradictory, reading."
date: "2026-03-01"
---

## The Objection

Matthew 27:5 states that Judas Iscariot, overcome with remorse, "went and hanged himself." Acts 1:18, in Peter's speech, says that Judas "falling headlong, he burst open in the middle and all his bowels gushed out." Critics argue these are two incompatible accounts of how Judas died, evidence that the New Testament contains factual errors about a basic historical event.

## The Orthodox Response

### The accounts describe different moments, not different deaths

The two texts are not competing over the same detail; they emphasize different aspects of a single sequence of events. Matthew reports the manner of death: Judas hanged himself. Acts, in a speech delivered some time later, reports the state in which his body was found. These are compatible, not contradictory, once it is recognized that a hanging body, left exposed over the rocky terrain of the Field of Blood, could plausibly fall and rupture — whether from a breaking branch or rope, decomposition, or being cut down.

This harmonization is ancient, not a modern apologetic invention. Church writers from at least the second century, including a fragment attributed to Papias, described a similar sequence: Judas's body swelling and eventually bursting after death, consistent with a hanging followed by a fall.

### Ancient biography did not require single-angle reporting

Ancient historiography, including the Gospels and Acts, regularly reports events selectively, choosing details relevant to the author's immediate purpose rather than attempting an exhaustive forensic account. Matthew, writing shortly after the events for a Jewish-Christian audience, connects Judas's death to the fulfillment of Old Testament prophecy concerning betrayal and the purchase of a field (drawing on Zechariah 11 and Jeremiah). Luke, writing Acts for Theophilus with different narrative priorities, reports the field's grim state as evidence known to "all the inhabitants of Jerusalem," reinforcing the public, verifiable nature of the event.

Two authors describing different facets of one event, for different purposes, is the ordinary condition of independent historical testimony — not a mark of contradiction. Courts and historians alike treat non-identical, complementary accounts of the same event as a sign of authentic, independent witness rather than fabrication, since fabricated accounts tend to be harmonized in advance.

### A note on the field's name

A secondary detail sometimes raised: Matthew says the chief priests bought the field with the returned betrayal money; Acts says Judas himself acquired it. Here again, ancient usage regularly attributes a purchase to the party whose money funded it, even when a third party executed the transaction — much as we might say a benefactor "built a hospital" that was constructed with donated funds. Both texts also agree the field became known as "Field of Blood" (Akeldama), for related but distinct reasons in each account (the price of blood in Matthew; the manner of death in Acts) — again complementary, not conflicting testimony.

## Historical Context

The Field of Blood tradition was evidently well established in first-century Jerusalem; both Matthew and Luke assume their readers can independently confirm the site's existence and grim reputation, which argues for the historicity of the underlying event rather than literary invention.

## Sources

- Papias, fragment preserved in Apollinaris of Laodicea
- Origen, *Commentary on Matthew*, addressing the same harmonization
- Craig Blomberg, *The Historical Reliability of the Gospels*, on ancient historiographical conventions
