---
title: "The Council of Chalcedon and the Two Natures of Christ"
description: "How the Fourth Ecumenical Council articulated the union of divine and human natures in the one person of Christ, and why the formula still guards against opposite errors today."
author: "Live Orthodox"
date: "2026-01-14"
category: "Church History"
tags: ["Christology", "Ecumenical Councils", "Chalcedon"]
featured: false
---

## A Question That Would Not Go Away

By the middle of the fifth century, the Church had already spent over a hundred years working out how to speak faithfully about Jesus Christ. Nicaea (325) had defended His full divinity against Arius. But a further question pressed just as urgently: if Christ is truly God and truly man, how do divinity and humanity relate within a single person?

Two tendencies threatened to unbalance the answer. One, associated loosely with Nestorius, seemed to divide Christ into two separate subjects, risking a Savior who was more partnership than person. The other, associated with Eutyches, so stressed the unity of Christ that His humanity appeared absorbed into His divinity, as a drop of vinegar is absorbed into the sea.

## The Chalcedonian Formula

The Fourth Ecumenical Council, meeting at Chalcedon in 451, produced a definition that has anchored Christian orthodoxy East and West ever since. Christ is confessed as one person (*hypostasis*) in two natures (*physeis*), united "without confusion, without change, without division, without separation."

Each phrase closes off a specific error. "Without confusion" and "without change" rule out any blending of the two natures into a hybrid third thing. "Without division" and "without separation" rule out treating Christ as two persons loosely cooperating. The natures remain fully what they are — full divinity, full humanity — united in a single subject who acts and is addressed as one "I."

## Why the Balance Matters

This is not abstract technical precision for its own sake. What is at stake, for Orthodox theology, is the very possibility of salvation as the Fathers understood it. If Christ is not fully human, then humanity itself has not truly been united to God and healed from within — the incarnation would touch human nature only externally. If Christ is not fully divine, then the union offered is not truly union with God at all.

St. Gregory of Nazianzus had already articulated the underlying principle a generation earlier: "that which is not assumed is not healed." For humanity's fallen condition, in all its dimensions, to be genuinely healed, the Word had to assume a complete and unabridged human nature — body, mind, and will — while remaining fully God.

## Reception and Ongoing Significance

Chalcedon's reception was not immediate or universal; some ancient Eastern churches, now called Oriental Orthodox, did not accept the council's formula, largely over terminology, and dialogue on this question continues to this day. Within Eastern Orthodoxy, however, Chalcedon stands alongside Nicaea and Constantinople as one of the pillars of Christological doctrine, safeguarding the mystery of the incarnation from being simplified in either direction.

The formula's enduring value lies precisely in its restraint. Chalcedon does not attempt to explain **how** two natures unite in one person — that remains, in Orthodox terms, a mystery approached apophatically. It draws the boundary lines within which the Church's faith in Christ can be held without collapsing into either division or confusion.

## Further Reading

- The Definition of Chalcedon (451)
- St. Gregory of Nazianzus, *Letter to Cledonius*
- John Behr, *The Way to Nicaea* and *The Nicene Faith*
