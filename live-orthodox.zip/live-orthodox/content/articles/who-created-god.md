---
title: "Answering the Objection: \"Who Created God?\""
description: "A common challenge to belief in God rests on a category mistake about what kind of thing God is claimed to be. Here is the Orthodox philosophical response, and its limits."
author: "Live Orthodox"
date: "2026-06-01"
category: "Apologetics"
tags: ["Cosmological Argument", "Philosophy of Religion", "Contingency"]
featured: true
---

## The Objection Stated

It is among the most common objections raised against belief in God: if everything needs a cause, what caused God? If the universe cannot simply exist without explanation, why should God be allowed to?

Stated this way, the objection sounds devastating. It is also, on inspection, built on a premise no classical theistic argument actually makes.

## The Premise the Argument Does Not Use

Cosmological arguments, from Aristotle through the Cappadocian Fathers to Aquinas, do not claim that "everything needs a cause." They claim something narrower and more defensible: that everything **contingent** — everything that could have failed to exist, or exists dependently on something else — requires an explanation outside itself.

The relevant question is not "what caused this thing to exist," full stop, but "does this thing exist necessarily, by the very kind of thing it is, or does it exist contingently, dependent on something beyond itself?" Contingent things, by definition, need an explanation for why they exist rather than not. A necessary being, if one exists, would not.

## Why God Is Proposed as Necessary, Not Contingent

Classical theism does not posit God as simply one more item in the universe that happens to lack a cause, as if by exception or special pleading. It argues that God is a different **kind** of reality altogether: not a contingent being among other contingent beings, but the uncaused ground of being itself, existing necessarily rather than dependently.

This is precisely the burden of the classical arguments: to show that a regress of contingent causes cannot terminate in another contingent cause without leaving the very existence of the whole chain unexplained, and that something existing necessarily, not contingently, is required to ground it. "Who created God?" therefore assumes the very premise under dispute — that God is a contingent, caused entity like the universe itself — rather than engaging the actual claim.

## An Analogy, With Its Limits

A rough analogy: asking "what number is bigger than infinity" treats infinity as though it were simply a very large member of the set of ordinary numbers, rather than a different kind of mathematical object altogether. The question misfires not because it is unanswerable in principle, but because it misunderstands the category of the thing it asks about.

The analogy has real limits, and Orthodox theology is careful not to lean on it too heavily — God is not a mathematical abstraction, and the doctrine of divine simplicity involves far more than a claim about causal chains. But the core logical point stands: asking for the cause of a *necessary* being is not a further, harder version of the same question asked of contingent beings. It is a different question, resting on a different premise, that the classical arguments never assert.

## What This Does and Does Not Establish

It is worth being candid about scope. This response defuses the specific objection; it does not, by itself, establish that the necessary being in question is the Triune God revealed in Christ, or has any particular attributes beyond necessity and being the ground of contingent existence. Orthodox apologetics has traditionally treated the cosmological argument as establishing a starting point — that a necessary, uncaused ground of being exists — while relying on revelation, the person of Christ, and the Church's experience to fill in who that God is.

## Further Reading

- St. Basil the Great, *Hexaemeron*, on the contingency of creation
- Thomas Aquinas, *Summa Theologica*, I, Q.2, Art.3 (the Five Ways)
- David Bentley Hart, *The Experience of God*, on classical theism versus theistic personalism
