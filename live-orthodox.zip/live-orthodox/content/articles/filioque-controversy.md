---
title: "The Filioque Controversy: Why the Orthodox Church Rejected an Addition to the Creed"
description: "An examination of the theological and historical dispute over the procession of the Holy Spirit, and why the Christian East regards the filioque clause as both doctrinally mistaken and uncanonical."
author: "Live Orthodox"
date: "2026-05-12"
category: "Church History"
tags: ["Trinity", "Creed", "East-West Schism", "Holy Spirit"]
featured: true
---

## A Single Word, A Divided Church

Few disputes in Christian history carry the theological weight of the filioque controversy, and yet the disagreement turns on a single Latin word: *filioque*, "and the Son." Its quiet insertion into the Nicene-Constantinopolitan Creed — changing "who proceeds from the Father" to "who proceeds from the Father **and the Son**" — became one of the deepest fractures between the Christian East and West.

For the Orthodox Church, the objection was never merely procedural. It concerned both **how** doctrine is properly established and **what** the Church actually believes about the inner life of the Holy Trinity.

## The Ecumenical Councils and the Creed

The Creed recited at Divine Liturgy every Sunday was not composed by a single bishop or bureau. It was formulated by the whole Church at the First Ecumenical Council (Nicaea, 325) and completed at the Second (Constantinople, 381), addressing precisely the question of the Holy Spirit's divinity and procession.

The Third Ecumenical Council (Ephesus, 431) explicitly forbade composing a "different faith" or altering the wording agreed upon by the Fathers. For the East, this canon was not incidental. It reflected the conviction that the Creed belongs to the whole Church, and that no single patriarchate — including Rome — has the unilateral authority to revise a formula ratified by an ecumenical council.

The filioque entered Western liturgical use gradually, first appearing in regional councils in Spain in the sixth century, likely as an anti-Arian clarification, before spreading through the Frankish kingdoms and eventually reaching Rome itself in the eleventh century.

## The Theological Objection

Beyond the question of authority lies a substantive theological concern. Orthodox theology, following the Cappadocian Fathers, holds that the Father is the sole *arche*, the single unoriginate source, within the Trinity. The Son is begotten of the Father alone; the Spirit proceeds from the Father alone. This preserves a clear and coherent account of how three distinct hypostases share one undivided essence without collapsing into confusion about their origin.

If the Spirit is said to proceed from the Father *and* the Son as from a single principle, Orthodox theologians argue, the very idea of the Father as sole source becomes unstable. Two persons cannot jointly serve as an "originating principle" without either being reduced to one, or the distinctions between the persons becoming blurred in a different way.

St. Photios the Great, and later St. Mark of Ephesus at the Council of Florence, both argued that the filioque effectively subordinates the Spirit's personal distinctiveness and disturbs the balance of relations that the Cappadocian formula was designed to protect.

## Not Merely a Technicality

It is tempting for modern readers to treat this as an abstract, even pedantic, dispute. Orthodox theology resists that framing. How the Trinity's inner relations are understood shapes how the Church understands revelation, grace, and the Spirit's ongoing role in the life of believers. A doctrine of God is never "merely academic" in Orthodox thought; it is inseparable from the Church's life of prayer and communion.

The filioque dispute, then, stands as a case study in how the Orthodox Church weighs conciliar authority, patristic consensus, and doctrinal precision together — and why it has resisted revising a formula it regards as belonging to the whole Body of Christ, not to any single see.

## Further Reading

- St. Photios the Great, *On the Mystagogy of the Holy Spirit*
- St. Mark of Ephesus, writings from the Council of Florence
- Vladimir Lossky, *The Mystical Theology of the Eastern Church*, chapter on the procession of the Holy Spirit
