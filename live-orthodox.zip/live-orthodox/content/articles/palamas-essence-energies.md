---
title: "St. Gregory Palamas and the Essence-Energies Distinction"
description: "How a fourteenth-century monk defended the possibility of real union with God against a rising rationalist critique, and why the distinction he articulated remains central to Orthodox theology."
author: "Live Orthodox"
date: "2026-03-18"
category: "Church Fathers"
tags: ["Palamas", "Hesychasm", "Theosis", "Byzantine Theology"]
featured: false
---

## A Dispute About Light

In the fourteenth century, monks on Mount Athos practiced a form of contemplative prayer, often called hesychasm ("stillness"), that some reported culminated in an experience of divine light — the same uncreated light, they claimed, that the apostles saw at Christ's Transfiguration on Mount Tabor.

A Calabrian philosopher named Barlaam, trained in Western scholastic method, ridiculed the claim. If God is absolutely transcendent and simple, he argued, any "light" the monks perceived had to be either a created symbol or a psychological illusion. To claim a literal vision of God's own uncreated glory seemed, to Barlaam, both philosophically incoherent and dangerously close to claiming direct comprehension of the divine essence.

## Palamas's Response

St. Gregory Palamas, a monk and later Archbishop of Thessaloniki, answered with a distinction that would become foundational to Orthodox theology: the difference between God's **essence** (*ousia*) and God's **energies** (*energeiai*).

God's essence, Palamas maintained, is absolutely transcendent, unknowable, and unparticipated — no creature can ever comprehend or share in what God is in Himself. Yet Scripture and patristic tradition consistently speak of real contact between God and creation: grace, glory, life, and power flowing out from God and genuinely reaching creatures. Palamas argued these are not created effects standing at a distance from God, but God's own **uncreated energies** — the true and real activity of God, distinct from His essence yet inseparable from it.

On this account, the light seen by the hesychasts was neither a mere symbol nor an impossible glimpse of the incomprehensible essence. It was a real, if partial, participation in God's uncreated energy — the same glory that shone at the Transfiguration.

## Why the Distinction Matters

The essence-energies distinction resolves a genuine philosophical puzzle: how can a wholly transcendent God be genuinely present and knowable without either compromising His transcendence or reducing "knowing God" to mere abstraction? Palamas's answer preserves both halves of the tension. God remains utterly beyond creaturely comprehension in His essence, while remaining truly, not merely symbolically, present and active through His energies.

This distinction underwrites the Orthodox doctrine of **theosis**, deification: the human person can be truly united to God, made "partaker of the divine nature" as 2 Peter 1:4 puts it, without any confusion between Creator and creature. Union is real because the energies are truly God; it is not a merging of essences because the essence remains beyond participation.

## A Council, Not Just an Argument

The matter was not settled by philosophical debate alone. A series of local councils in Constantinople (1341, 1347, 1351) affirmed Palamas's theology as an authentic expression of the Church's faith, and Barlaam's position was condemned. St. Gregory Palamas is commemorated on the second Sunday of Great Lent, a placement that signals how central the Orthodox Church considers this teaching to the whole shape of the Lenten journey toward Pascha.

## Further Reading

- St. Gregory Palamas, *The Triads*
- John Meyendorff, *A Study of Gregory Palamas*
- Kallistos Ware, *The Orthodox Way*, chapter on the knowledge of God
