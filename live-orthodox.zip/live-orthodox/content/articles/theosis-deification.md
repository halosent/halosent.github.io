---
title: "Theosis: The Orthodox Doctrine of Deification"
description: "An introduction to the Orthodox teaching that the goal of the Christian life is real, participatory union with God — and why this shapes Orthodox anthropology, ethics, and worship."
author: "Live Orthodox"
date: "2026-02-20"
category: "Theology"
tags: ["Theosis", "Salvation", "Anthropology", "Grace"]
featured: false
---

## Salvation as Union, Not Only Acquittal

Ask an Orthodox Christian what salvation means, and the answer will rarely stop at forgiveness of sins. It will almost certainly include the word *theosis* — deification, or divinization: the conviction that the purpose of human life is to become, by grace, what God is by nature.

This is not a claim that human beings become God in essence. St. Athanasius's famous formula — "God became man so that man might become god" — has always been read within careful guardrails. The union in view is a union of grace and energy, not a merging of natures. Humanity does not absorb divinity; it is transfigured by participation in it, the way iron placed in fire glows with the fire's heat and light without ceasing to be iron.

## Scriptural and Patristic Roots

The apostle Peter writes that believers are called to become "partakers of the divine nature" (2 Peter 1:4), a phrase Orthodox theology treats as programmatic rather than merely poetic. The Gospel of John records Christ praying "that they may be one, as we are one... I in them and you in me" (John 17:22–23), language of indwelling and union that Orthodox exegesis takes with full seriousness.

The Church Fathers developed this theme extensively. St. Irenaeus of Lyons wrote of the Word of God becoming what we are, so that He might make us what He Himself is. St. Maximus the Confessor described the entire arc of salvation history as oriented toward this union, in which humanity, and through humanity the whole created order, is drawn into communion with God.

## Grace, Not Merit

Because theosis is a real transformation and not a legal fiction, Orthodox theology places heavy emphasis on the ascetic and sacramental life as the ordinary means by which this transformation occurs: prayer, fasting, repentance, and above all participation in the sacraments, especially the Eucharist. Yet theosis is never treated as a human achievement that earns divine reward. It is God's grace working synergistically with human freedom and effort — the human person is invited to cooperate with a transformation that only God can accomplish.

This is the doctrine of **synergy**: grace does not override human freedom, nor does human effort alone produce holiness. The two act together, without either being reduced to the other.

## Consequences for Orthodox Life

Theosis is not a doctrine reserved for mystics or monastics. It shapes ordinary Orthodox piety in visible ways. Icons are venerated because they depict saints who have been genuinely transfigured by divine glory. Fasting and almsgiving are practiced not merely as moral discipline but as ways of loosening the grip of the passions so that communion with God can deepen. Even Orthodox ethics is oriented less around rule-following than around the cultivation of a character capable of receiving and reflecting divine love.

Understood this way, theosis reframes the entire Christian life: not as a probationary period awaiting a distant verdict, but as the beginning, here and now, of a union with God intended to grow without end.

## Further Reading

- St. Athanasius, *On the Incarnation*
- St. Maximus the Confessor, *Ambigua*
- Georgios Mantzaridis, *The Deification of Man*
