/**
 * Generates sitemap.xml inside the static export output ("out/") after `next build`.
 * Update SITE_URL below (or set the SITE_URL env var) to your real deployed URL
 * before running a production build.
 */
const fs = require('fs');
const path = require('path');

const SITE_URL = (process.env.SITE_URL || 'https://example.github.io/live-orthodox').replace(/\/$/, '');
const OUT_DIR = path.join(process.cwd(), 'out');

function listSlugs(dir) {
  const full = path.join(process.cwd(), dir);
  if (!fs.existsSync(full)) return [];
  return fs
    .readdirSync(full)
    .filter((f) => f.endsWith('.md'))
    .map((f) => f.replace(/\.md$/, ''));
}

const staticRoutes = ['', 'articles/', 'contradictions/', 'philosophy/', 'about/'];
const articleRoutes = listSlugs('content/articles').map((s) => `articles/${s}/`);
const contradictionRoutes = listSlugs('content/contradictions').map((s) => `contradictions/${s}/`);

const allRoutes = [...staticRoutes, ...articleRoutes, ...contradictionRoutes];

const urlEntries = allRoutes
  .map((route) => {
    const loc = `${SITE_URL}/${route}`;
    return `  <url>\n    <loc>${loc}</loc>\n  </url>`;
  })
  .join('\n');

const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urlEntries}\n</urlset>\n`;

if (!fs.existsSync(OUT_DIR)) {
  console.warn('Warning: "out/" directory not found. Run `next build` first.');
  process.exit(0);
}

fs.writeFileSync(path.join(OUT_DIR, 'sitemap.xml'), xml, 'utf-8');

const robots = `User-agent: *\nAllow: /\n\nSitemap: ${SITE_URL}/sitemap.xml\n`;
fs.writeFileSync(path.join(OUT_DIR, 'robots.txt'), robots, 'utf-8');

console.log(`Generated sitemap.xml with ${allRoutes.length} routes at ${OUT_DIR}`);
