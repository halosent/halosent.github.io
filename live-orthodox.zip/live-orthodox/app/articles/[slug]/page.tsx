import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import AnimatedBackground from '@/components/AnimatedBackground';
import ArticleView from '@/components/ArticleView';
import { getAllArticles, getAllArticleSlugs, getArticleBySlug } from '@/lib/content';
import { extractToc } from '@/lib/toc';
import { SITE } from '@/lib/site';

export function generateStaticParams() {
  return getAllArticleSlugs().map((slug) => ({ slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const article = getArticleBySlug(params.slug);
  if (!article) return {};
  return {
    title: article.title,
    description: article.description,
    alternates: { canonical: `/articles/${article.slug}/` },
    openGraph: {
      type: 'article',
      title: article.title,
      description: article.description,
      url: `${SITE.url}/articles/${article.slug}/`,
      publishedTime: article.date,
      authors: [article.author],
    },
    twitter: {
      card: 'summary_large_image',
      title: article.title,
      description: article.description,
    },
  };
}

export default function ArticlePage({ params }: { params: { slug: string } }) {
  const article = getArticleBySlug(params.slug);
  if (!article) notFound();

  const toc = extractToc(article.content);
  const related = getAllArticles()
    .filter((a) => a.slug !== article.slug && a.category === article.category)
    .slice(0, 3);
  const fallbackRelated =
    related.length > 0
      ? related
      : getAllArticles()
          .filter((a) => a.slug !== article.slug)
          .slice(0, 3);

  return (
    <>
      <AnimatedBackground variant="articles" />
      <ArticleView article={article} toc={toc} related={fallbackRelated} />
    </>
  );
}
