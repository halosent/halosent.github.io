import { Suspense } from 'react';
import type { Metadata } from 'next';
import AnimatedBackground from '@/components/AnimatedBackground';
import ArticlesExplorer from '@/components/ArticlesExplorer';
import { getAllArticles } from '@/lib/content';

export const metadata: Metadata = {
  title: 'Articles',
  description:
    'Browse Live Orthodox articles on Eastern Orthodox theology, philosophy, church history, and apologetics.',
  alternates: { canonical: '/articles/' },
};

export default function ArticlesPage() {
  const articles = getAllArticles();

  return (
    <>
      <AnimatedBackground variant="articles" />
      <section className="mx-auto max-w-6xl px-6 pb-20 pt-20">
        <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Library</p>
        <h1 className="mt-2 font-serif text-4xl text-ink">Articles</h1>
        <p className="mt-3 max-w-2xl text-ink/60">
          Scholarly, accessible writing on Orthodox theology, philosophy, church history, and biblical
          interpretation.
        </p>

        <div className="mt-10">
          <Suspense fallback={<div className="h-40 animate-pulse rounded-xl border border-line bg-paper" />}>
            <ArticlesExplorer articles={articles} />
          </Suspense>
        </div>
      </section>
    </>
  );
}
