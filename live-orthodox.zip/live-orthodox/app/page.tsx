import Link from 'next/link';
import { ArrowRight, BookOpen, Compass } from 'lucide-react';
import AnimatedBackground from '@/components/AnimatedBackground';
import ArticleCard from '@/components/ArticleCard';
import QuoteBlock from '@/components/QuoteBlock';
import { getAllArticles, CATEGORIES } from '@/lib/content';
import { SITE } from '@/lib/site';

export default function HomePage() {
  const articles = getAllArticles();
  const featured = articles.filter((a) => a.featured).slice(0, 3);
  const latest = articles.slice(0, 6);

  return (
    <>
      <AnimatedBackground variant="home" />

      {/* Hero */}
      <section className="mx-auto max-w-4xl px-6 pb-20 pt-24 text-center sm:pt-32">
        <span className="animate-rise inline-block rounded-full border border-gold/30 bg-gold/[0.06] px-4 py-1.5 text-xs font-medium tracking-wide text-gold-dark">
          Owned and maintained by Unified
        </span>
        <h1 className="animate-rise mt-6 font-serif text-5xl leading-[1.1] tracking-tight text-ink sm:text-6xl" style={{ animationDelay: '0.05s' }}>
          Live Orthodox
        </h1>
        <p className="animate-rise mx-auto mt-6 max-w-2xl text-balance text-lg leading-relaxed text-ink/65" style={{ animationDelay: '0.1s' }}>
          {SITE.tagline}
        </p>
        <div className="animate-rise mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row" style={{ animationDelay: '0.15s' }}>
          <Link
            href="/articles/"
            className="group flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-medium text-paper transition-all hover:bg-gold-dark"
          >
            <BookOpen className="h-4 w-4" strokeWidth={1.75} />
            Read Articles
            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
          </Link>
          <Link
            href="/philosophy/"
            className="flex items-center gap-2 rounded-full border border-line bg-paper px-6 py-3 text-sm font-medium text-ink transition-all hover:border-gold/50 hover:text-gold-dark"
          >
            <Compass className="h-4 w-4" strokeWidth={1.75} />
            Explore Topics
          </Link>
        </div>
      </section>

      {/* Featured Articles */}
      {featured.length > 0 && (
        <section className="mx-auto max-w-6xl px-6 py-16">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Featured</p>
              <h2 className="mt-2 font-serif text-3xl text-ink">Featured Articles</h2>
            </div>
            <Link href="/articles/" className="hidden text-sm text-ink/60 hover:text-gold-dark sm:block">
              View all articles →
            </Link>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {featured.map((article) => (
              <ArticleCard key={article.slug} article={article} />
            ))}
          </div>
        </section>
      )}

      {/* Browse Topics */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Browse</p>
        <h2 className="mt-2 font-serif text-3xl text-ink">Explore by Topic</h2>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat}
              href={`/articles/?category=${encodeURIComponent(cat)}`}
              className="group rounded-xl border border-line bg-paper p-5 transition-all hover:-translate-y-0.5 hover:border-gold/40"
            >
              <span className="font-serif text-base text-ink group-hover:text-gold-dark">{cat}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Latest Articles */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Recent</p>
            <h2 className="mt-2 font-serif text-3xl text-ink">Latest Articles</h2>
          </div>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {latest.map((article) => (
            <ArticleCard key={article.slug} article={article} />
          ))}
        </div>
      </section>

      {/* Quotes */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Wisdom</p>
        <h2 className="mt-2 font-serif text-3xl text-ink">Words Worth Returning To</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          <QuoteBlock
            kind="Scripture"
            source="John 8:32"
            quote="You will know the truth, and the truth will set you free."
          />
          <QuoteBlock
            kind="Church Father"
            source="St. Basil the Great"
            quote="The bread you do not use is the bread of the hungry; the garment hanging in your closet is the garment of the one who is naked."
          />
          <QuoteBlock
            kind="Orthodox Philosopher"
            source="Fr. Georges Florovsky"
            quote="Christianity is not merely a message but above all a fact — the fact of the Incarnation."
          />
        </div>
      </section>

      {/* Closing CTA */}
      <section className="mx-auto max-w-4xl px-6 pb-28 pt-8 text-center">
        <div className="rounded-2xl border border-line bg-paper px-8 py-14">
          <h2 className="font-serif text-2xl text-ink">Have a question or an objection?</h2>
          <p className="mx-auto mt-3 max-w-lg text-sm leading-relaxed text-ink/60">
            The Contradictions database gathers common objections to Christian belief alongside careful,
            sourced Orthodox responses.
          </p>
          <Link
            href="/contradictions/"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-gold-dark px-6 py-3 text-sm font-medium text-paper transition-all hover:bg-ink"
          >
            Browse the Contradictions Database
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </section>
    </>
  );
}
