import type { Metadata } from 'next';
import AnimatedBackground from '@/components/AnimatedBackground';

export const metadata: Metadata = {
  title: 'About',
  description: 'The mission of Live Orthodox and its ownership by Unified.',
  alternates: { canonical: '/about/' },
};

export default function AboutPage() {
  return (
    <>
      <AnimatedBackground variant="about" />
      <section className="mx-auto max-w-reading px-6 pb-24 pt-20">
        <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">About</p>
        <h1 className="mt-2 font-serif text-4xl text-ink">About Live Orthodox</h1>

        <div className="prose-orthodox prose prose-neutral mt-8 max-w-none prose-headings:font-serif prose-headings:font-semibold">
          <h2>Our Mission</h2>
          <p>
            Live Orthodox exists to make Eastern Orthodox Christian theology, philosophy, and church history
            accessible without sacrificing scholarly seriousness. Orthodoxy carries nearly two thousand years
            of continuous theological reflection, conciliar decision-making, and lived spiritual practice — a
            tradition too often reduced, in popular discourse, to caricature or omitted from the conversation
            altogether.
          </p>
          <p>
            Our goal is straightforward: to explain what the Orthodox Church actually teaches, why it teaches
            it, and how that teaching responds to the honest questions and objections raised by skeptics,
            inquirers, and believers alike.
          </p>

          <h2>Why Orthodox Philosophy and Apologetics Matter</h2>
          <p>
            Apologetics, properly understood, is not about winning arguments. It is the disciplined practice
            of giving a reasoned account of the faith — "always being prepared to make a defense to anyone who
            asks you for a reason for the hope that is in you," in the words of 1 Peter 3:15, offered "with
            gentleness and respect."
          </p>
          <p>
            Philosophy, in the Orthodox tradition, has never been treated as a threat to faith but as one of
            its long-standing conversation partners — from the Cappadocian Fathers' engagement with Greek
            philosophy to contemporary Orthodox thinkers working through questions of ethics, personhood, and
            the philosophy of science. Live Orthodox continues that conversation: taking objections seriously,
            citing sources, and distinguishing carefully between what the Church has formally defined and
            where legitimate theological opinion varies.
          </p>

          <h2>What You Will Find Here</h2>
          <p>
            Articles on theology, philosophy, church history, and biblical interpretation; a searchable
            database of alleged contradictions paired with sourced Orthodox responses; and a reading
            experience — including a distraction-free Immersive Reader mode — built for people who want to sit
            with an idea rather than skim past it.
          </p>

          <h2>Ownership</h2>
          <p>Live Orthodox is owned and maintained by Unified.</p>
          <p>All content, ownership, and credits belong to Unified.</p>
        </div>
      </section>
    </>
  );
}
