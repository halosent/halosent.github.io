import type { Metadata } from 'next';
import AnimatedBackground from '@/components/AnimatedBackground';
import ContradictionsExplorer from '@/components/ContradictionsExplorer';
import { getAllContradictions } from '@/lib/content';

export const metadata: Metadata = {
  title: 'Contradictions Database',
  description:
    'A searchable database of alleged biblical contradictions and objections to Christianity, each paired with a careful, sourced Orthodox response.',
  alternates: { canonical: '/contradictions/' },
};

export default function ContradictionsPage() {
  const items = getAllContradictions();

  return (
    <>
      <AnimatedBackground variant="contradictions" />
      <section className="mx-auto max-w-6xl px-6 pb-20 pt-20">
        <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Database</p>
        <h1 className="mt-2 font-serif text-4xl text-ink">Contradictions</h1>
        <p className="mt-3 max-w-2xl text-ink/60">
          A growing, searchable collection of alleged biblical contradictions and common objections to
          Christian belief, each addressed with historical, philosophical, and theological context.
        </p>

        <div className="mt-10">
          <ContradictionsExplorer items={items} />
        </div>
      </section>
    </>
  );
}
