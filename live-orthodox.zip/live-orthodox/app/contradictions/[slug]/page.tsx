import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, BookMarked } from 'lucide-react';
import AnimatedBackground from '@/components/AnimatedBackground';
import Markdown from '@/components/Markdown';
import {
  getAllContradictions,
  getAllContradictionSlugs,
  getContradictionBySlug,
  CONTRADICTION_TYPES,
} from '@/lib/content';
import { SITE } from '@/lib/site';

export function generateStaticParams() {
  return getAllContradictionSlugs().map((slug) => ({ slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const item = getContradictionBySlug(params.slug);
  if (!item) return {};
  return {
    title: item.title,
    description: item.summary,
    alternates: { canonical: `/contradictions/${item.slug}/` },
    openGraph: {
      type: 'article',
      title: item.title,
      description: item.summary,
      url: `${SITE.url}/contradictions/${item.slug}/`,
    },
  };
}

export default function ContradictionPage({ params }: { params: { slug: string } }) {
  const item = getContradictionBySlug(params.slug);
  if (!item) notFound();

  const typeLabel = CONTRADICTION_TYPES.find((t) => t.value === item.type)?.label ?? item.type;
  const more = getAllContradictions()
    .filter((c) => c.slug !== item.slug && c.type === item.type)
    .slice(0, 3);

  return (
    <>
      <AnimatedBackground variant="contradictions" />
      <article className="mx-auto max-w-reading px-6 pb-24 pt-16">
        <Link href="/contradictions/" className="flex items-center gap-1.5 text-sm text-ink/50 hover:text-gold-dark">
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Contradictions
        </Link>

        <span className="mt-6 inline-block rounded-full bg-ink/[0.04] px-3 py-1 text-xs font-medium tracking-wide text-ink/60">
          {typeLabel}
        </span>
        <h1 className="mt-4 font-serif text-4xl leading-tight text-ink">{item.title}</h1>

        <blockquote className="mt-6 rounded-xl border-l-4 border-gold bg-gold/[0.06] px-5 py-4 font-serif text-lg italic text-ink/80">
          &ldquo;{item.claim}&rdquo;
        </blockquote>

        {item.verses.length > 0 && (
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <BookMarked className="h-4 w-4 text-gold-dark" strokeWidth={1.75} />
            {item.verses.map((v) => (
              <span key={v} className="rounded-md bg-canvas px-2.5 py-1 text-xs text-ink/60">
                {v}
              </span>
            ))}
          </div>
        )}

        <div className="mt-10">
          <Markdown content={item.content} />
        </div>
      </article>

      {more.length > 0 && (
        <section className="border-t border-line bg-paper py-16">
          <div className="mx-auto max-w-4xl px-6">
            <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Related</p>
            <h2 className="mt-2 font-serif text-2xl text-ink">More {typeLabel} Entries</h2>
            <ul className="mt-6 space-y-3">
              {more.map((c) => (
                <li key={c.slug}>
                  <Link
                    href={`/contradictions/${c.slug}/`}
                    className="block rounded-lg border border-line bg-canvas px-5 py-4 text-sm text-ink/75 transition-colors hover:border-gold/40 hover:text-gold-dark"
                  >
                    {c.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}
    </>
  );
}
