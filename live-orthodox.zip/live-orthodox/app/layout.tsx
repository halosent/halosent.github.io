import type { Metadata } from 'next';
import './globals.css';
import Nav from '@/components/Nav';
import Footer from '@/components/Footer';
import { SITE } from '@/lib/site';

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: {
    default: `${SITE.name} — Orthodox Christian Philosophy & Apologetics`,
    template: `%s — ${SITE.name}`,
  },
  description: SITE.description,
  keywords: [
    'Eastern Orthodox',
    'Orthodox Christianity',
    'Orthodox theology',
    'apologetics',
    'philosophy',
    'church history',
    'biblical contradictions',
  ],
  authors: [{ name: SITE.owner }],
  creator: SITE.owner,
  publisher: SITE.owner,
  openGraph: {
    type: 'website',
    siteName: SITE.name,
    title: `${SITE.name} — Orthodox Christian Philosophy & Apologetics`,
    description: SITE.description,
    url: SITE.url,
  },
  twitter: {
    card: 'summary_large_image',
    title: `${SITE.name} — Orthodox Christian Philosophy & Apologetics`,
    description: SITE.description,
    site: SITE.twitterHandle,
  },
  alternates: {
    canonical: '/',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Source+Serif+4:opsz,wght@8..60,400;8..60,500;8..60,600;8..60,700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-canvas font-sans text-ink antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] focus:rounded-md focus:bg-ink focus:px-4 focus:py-2 focus:text-paper"
        >
          Skip to content
        </a>
        <Nav />
        <main id="main-content">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
