import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import AnimatedBackground from '@/components/AnimatedBackground';
import ArticleCard from '@/components/ArticleCard';
import { getAllArticles, CATEGORIES } from '@/lib/content';

export const metadata: Metadata = {
  title: 'Philosophy & Topics',
  description:
    'Explore Live Orthodox by topic: philosophy, theology, church history, church fathers, ethics, science, and apologetics.',
  alternates: { canonical: '/philosophy/' },
};

export default function PhilosophyPage() {
  const articles = getAllArticles();

  return (
    <>
      <AnimatedBackground variant="about" />
      <section className="mx-auto max-w-6xl px-6 pb-10 pt-20">
        <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Topics</p>
        <h1 className="mt-2 font-serif text-4xl text-ink">Philosophy &amp; Topics</h1>
        <p className="mt-3 max-w-2xl text-ink/60">
          Orthodox thought treats philosophy and theology as companions rather than rivals. Browse writing
          organized by the questions it engages.
        </p>
      </section>

      {CATEGORIES.map((category) => {
        const items = articles.filter((a) => a.category === category);
        if (items.length === 0) return null;
        return (
          <section key={category} className="mx-auto max-w-6xl px-6 py-10">
            <div className="mb-6 flex items-end justify-between">
              <h2 className="font-serif text-2xl text-ink">{category}</h2>
              <Link
                href={`/articles/?category=${encodeURIComponent(category)}`}
                className="flex items-center gap-1 text-sm text-ink/55 hover:text-gold-dark"
              >
                View all <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
            <div className="grid gap-6 md:grid-cols-3">
              {items.slice(0, 3).map((a) => (
                <ArticleCard key={a.slug} article={a} />
              ))}
            </div>
          </section>
        );
      })}
    </>
  );
}
