import { Quote } from 'lucide-react';

export default function QuoteBlock({
  quote,
  source,
  kind,
}: {
  quote: string;
  source: string;
  kind: 'Scripture' | 'Church Father' | 'Orthodox Philosopher';
}) {
  return (
    <figure className="relative rounded-xl border border-line bg-paper p-8">
      <Quote className="h-6 w-6 text-gold/50" strokeWidth={1.5} />
      <blockquote className="mt-4 font-serif text-lg leading-relaxed text-ink/85">
        {quote}
      </blockquote>
      <figcaption className="mt-5 flex items-center gap-2 text-sm text-ink/50">
        <span className="text-gold-dark">{source}</span>
        <span aria-hidden="true">·</span>
        <span>{kind}</span>
      </figcaption>
    </figure>
  );
}
