'use client';

import { useMemo, useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import ContradictionCard from '@/components/ContradictionCard';
import type { Contradiction } from '@/lib/types';
import { CONTRADICTION_TYPES } from '@/lib/types';

export default function ContradictionsExplorer({ items }: { items: Contradiction[] }) {
  const [query, setQuery] = useState('');
  const [type, setType] = useState<string>('All');

  const filtered = useMemo(() => {
    let result = items;
    if (type !== 'All') result = result.filter((c) => c.type === type);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      result = result.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.claim.toLowerCase().includes(q) ||
          c.summary.toLowerCase().includes(q) ||
          c.verses.some((v) => v.toLowerCase().includes(q))
      );
    }
    return result;
  }, [items, type, query]);

  return (
    <div>
      <div className="flex flex-col gap-4 rounded-xl border border-line bg-paper p-5 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by claim, verse, or keyword…"
            className="w-full rounded-lg border border-line bg-canvas py-2.5 pl-9 pr-3 text-sm text-ink placeholder:text-ink/40 focus:border-gold/50 focus:outline-none"
            aria-label="Search contradictions"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterPill active={type === 'All'} onClick={() => setType('All')}>
            All
          </FilterPill>
          {CONTRADICTION_TYPES.map((t) => (
            <FilterPill key={t.value} active={type === t.value} onClick={() => setType(t.value)}>
              {t.label}
            </FilterPill>
          ))}
        </div>
      </div>

      <p className="mt-4 text-sm text-ink/50">
        {filtered.length} entr{filtered.length === 1 ? 'y' : 'ies'} found
      </p>

      {filtered.length > 0 ? (
        <div className="mt-6 grid gap-6 md:grid-cols-2">
          {filtered.map((item) => (
            <ContradictionCard key={item.slug} item={item} />
          ))}
        </div>
      ) : (
        <div className="mt-10 rounded-xl border border-dashed border-line bg-paper px-6 py-16 text-center">
          <p className="text-ink/60">No entries match your search.</p>
        </div>
      )}
    </div>
  );
}

function FilterPill({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`whitespace-nowrap rounded-full border px-3.5 py-2 text-xs font-medium transition-colors ${
        active ? 'border-gold bg-gold/15 text-gold-dark' : 'border-line text-ink/55 hover:border-gold/40'
      }`}
    >
      {children}
    </button>
  );
}
