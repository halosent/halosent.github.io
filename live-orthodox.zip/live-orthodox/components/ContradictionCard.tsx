import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';
import type { Contradiction } from '@/lib/types';
import { CONTRADICTION_TYPES } from '@/lib/types';

export default function ContradictionCard({ item }: { item: Contradiction }) {
  const typeLabel = CONTRADICTION_TYPES.find((t) => t.value === item.type)?.label ?? item.type;
  return (
    <Link
      href={`/contradictions/${item.slug}/`}
      className="group relative flex flex-col rounded-xl border border-line bg-paper p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold/40 hover:shadow-[0_12px_32px_-16px_rgba(200,169,106,0.35)]"
    >
      <div className="flex items-center justify-between">
        <span className="rounded-full bg-ink/[0.04] px-3 py-1 text-xs font-medium tracking-wide text-ink/60">
          {typeLabel}
        </span>
        <ArrowUpRight className="h-4 w-4 text-ink/30 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-gold-dark" />
      </div>
      <h3 className="mt-4 font-serif text-lg leading-snug text-ink transition-colors group-hover:text-gold-dark">
        {item.title}
      </h3>
      <p className="mt-2.5 line-clamp-2 text-sm italic leading-relaxed text-ink/55">&ldquo;{item.claim}&rdquo;</p>
      <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-ink/60">{item.summary}</p>
      {item.verses.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-1.5 border-t border-line pt-4">
          {item.verses.slice(0, 3).map((v) => (
            <span key={v} className="rounded-md bg-canvas px-2 py-1 text-[11px] text-ink/50">
              {v}
            </span>
          ))}
        </div>
      )}
    </Link>
  );
}
