'use client';

import { useState } from 'react';
import Link from 'next/link';
import { BookOpenText, Clock, Calendar, User } from 'lucide-react';
import Markdown from '@/components/Markdown';
import ImmersiveReader from '@/components/ImmersiveReader';
import ArticleCard from '@/components/ArticleCard';
import type { Article } from '@/lib/types';
import type { TocItem } from '@/lib/toc';

function formatDate(date: string) {
  if (!date) return '';
  return new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

export default function ArticleView({
  article,
  toc,
  related,
}: {
  article: Article;
  toc: TocItem[];
  related: Article[];
}) {
  const [reading, setReading] = useState(false);

  return (
    <>
      <article className="mx-auto max-w-6xl px-6 pb-24 pt-16">
        <div className="mx-auto max-w-reading">
          <span className="rounded-full border border-gold/30 bg-gold/[0.07] px-3 py-1 text-xs font-medium tracking-wide text-gold-dark">
            {article.category}
          </span>
          <h1 className="mt-5 font-serif text-4xl leading-tight text-ink sm:text-5xl">{article.title}</h1>
          <p className="mt-4 text-lg leading-relaxed text-ink/60">{article.description}</p>

          <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 border-y border-line py-4 text-sm text-ink/55">
            <span className="flex items-center gap-1.5">
              <User className="h-3.5 w-3.5" strokeWidth={1.75} />
              {article.author}
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" strokeWidth={1.75} />
              {formatDate(article.date)}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" strokeWidth={1.75} />
              {article.readingTime}
            </span>
            <button
              onClick={() => setReading(true)}
              className="ml-auto flex items-center gap-2 rounded-full bg-ink px-4 py-2 text-xs font-medium text-paper transition-colors hover:bg-gold-dark"
            >
              <BookOpenText className="h-3.5 w-3.5" />
              Immersive Reader
            </button>
          </div>
        </div>

        <div className="mx-auto mt-10 grid max-w-6xl gap-10 lg:grid-cols-[1fr_220px]">
          <div className="mx-auto w-full max-w-reading">
            <Markdown content={article.content} />

            {article.tags.length > 0 && (
              <div className="mt-10 flex flex-wrap gap-2 border-t border-line pt-6">
                {article.tags.map((t) => (
                  <span key={t} className="rounded-full bg-canvas px-3 py-1 text-xs text-ink/55">
                    #{t}
                  </span>
                ))}
              </div>
            )}
          </div>

          {toc.length > 0 && (
            <aside className="hidden lg:block">
              <div className="sticky top-24">
                <p className="text-xs font-medium uppercase tracking-widest text-ink/40">On this page</p>
                <nav className="mt-4 space-y-2 border-l border-line pl-4">
                  {toc.map((item) => (
                    <a
                      key={item.id}
                      href={`#${item.id}`}
                      className={`block text-sm text-ink/55 transition-colors hover:text-gold-dark ${
                        item.depth === 3 ? 'pl-3' : ''
                      }`}
                    >
                      {item.text}
                    </a>
                  ))}
                </nav>
              </div>
            </aside>
          )}
        </div>
      </article>

      {related.length > 0 && (
        <section className="border-t border-line bg-paper py-16">
          <div className="mx-auto max-w-6xl px-6">
            <p className="text-xs font-medium uppercase tracking-widest text-gold-dark">Continue reading</p>
            <h2 className="mt-2 font-serif text-2xl text-ink">Related Articles</h2>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {related.map((a) => (
                <ArticleCard key={a.slug} article={a} />
              ))}
            </div>
          </div>
        </section>
      )}

      {reading && (
        <ImmersiveReader
          title={article.title}
          content={article.content}
          toc={toc}
          onClose={() => setReading(false)}
        />
      )}
    </>
  );
}
