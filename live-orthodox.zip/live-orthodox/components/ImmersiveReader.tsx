'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import {
  X,
  Minus,
  Plus,
  Sun,
  Moon,
  Coffee,
  Maximize,
  Minimize,
  AlignJustify,
  MoveHorizontal,
  Type,
  BookOpenText,
} from 'lucide-react';
import Markdown from '@/components/Markdown';
import type { TocItem } from '@/lib/toc';

type Theme = 'light' | 'sepia' | 'dark';
type FontFamily = 'serif' | 'sans';
type LineSpacing = 'compact' | 'comfortable' | 'relaxed';
type Width = 'narrow' | 'medium' | 'wide';

type Prefs = {
  fontSize: number; // px
  theme: Theme;
  fontFamily: FontFamily;
  lineSpacing: LineSpacing;
  width: Width;
};

const DEFAULT_PREFS: Prefs = {
  fontSize: 19,
  theme: 'light',
  fontFamily: 'serif',
  lineSpacing: 'comfortable',
  width: 'medium',
};

const STORAGE_KEY = 'live-orthodox-reader-prefs';

const LINE_HEIGHT: Record<LineSpacing, string> = {
  compact: '1.55',
  comfortable: '1.85',
  relaxed: '2.15',
};

const WIDTH_PX: Record<Width, string> = {
  narrow: '620px',
  medium: '760px',
  wide: '900px',
};

export default function ImmersiveReader({
  title,
  content,
  toc,
  onClose,
}: {
  title: string;
  content: string;
  toc: TocItem[];
  onClose: () => void;
}) {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [progress, setProgress] = useState(0);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [showToc, setShowToc] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Load saved preferences
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setPrefs({ ...DEFAULT_PREFS, ...JSON.parse(raw) });
    } catch {
      // ignore malformed storage
    }
    closeButtonRef.current?.focus();
  }, []);

  const persist = useCallback((next: Prefs) => {
    setPrefs(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // storage unavailable; preferences simply won't persist
    }
  }, []);

  // Escape to close, lock body scroll
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [onClose]);

  // Reading progress + active heading tracking
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = el;
      const pct = scrollHeight <= clientHeight ? 100 : (scrollTop / (scrollHeight - clientHeight)) * 100;
      setProgress(Math.min(100, Math.max(0, pct)));

      let current: string | null = null;
      for (const item of toc) {
        const heading = el.querySelector<HTMLElement>(`#${CSS.escape(item.id)}`);
        if (heading && heading.offsetTop - el.offsetTop <= scrollTop + 120) {
          current = item.id;
        }
      }
      setActiveId(current);
    };
    onScroll();
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => el.removeEventListener('scroll', onScroll);
  }, [toc]);

  const scrollToHeading = (id: string) => {
    const el = scrollRef.current;
    const heading = el?.querySelector<HTMLElement>(`#${CSS.escape(id)}`);
    if (el && heading) {
      el.scrollTo({ top: heading.offsetTop - el.offsetTop - 24, behavior: 'smooth' });
    }
    setShowToc(false);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const themeClass =
    prefs.theme === 'dark' ? 'reader-theme-dark' : prefs.theme === 'sepia' ? 'reader-theme-sepia' : 'reader-theme-light';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Immersive reader: ${title}`}
      className={`fixed inset-0 z-[100] flex flex-col ${themeClass}`}
    >
      {/* Progress bar */}
      <div className="h-0.5 w-full bg-black/10">
        <div className="h-full bg-gold transition-[width] duration-150" style={{ width: `${progress}%` }} />
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-current/10 px-4 py-3 sm:px-8">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <ToolbarButton
            label="Decrease font size"
            onClick={() => persist({ ...prefs, fontSize: Math.max(15, prefs.fontSize - 1) })}
          >
            <Minus className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton
            label="Increase font size"
            onClick={() => persist({ ...prefs, fontSize: Math.min(28, prefs.fontSize + 1) })}
          >
            <Plus className="h-4 w-4" />
          </ToolbarButton>

          <Divider />

          <ToolbarButton
            label="Toggle font family"
            active={prefs.fontFamily === 'serif'}
            onClick={() => persist({ ...prefs, fontFamily: prefs.fontFamily === 'serif' ? 'sans' : 'serif' })}
          >
            <Type className="h-4 w-4" />
          </ToolbarButton>

          <ToolbarButton
            label="Cycle line spacing"
            onClick={() => {
              const order: LineSpacing[] = ['compact', 'comfortable', 'relaxed'];
              const next = order[(order.indexOf(prefs.lineSpacing) + 1) % order.length];
              persist({ ...prefs, lineSpacing: next });
            }}
          >
            <AlignJustify className="h-4 w-4" />
          </ToolbarButton>

          <ToolbarButton
            label="Cycle reading width"
            onClick={() => {
              const order: Width[] = ['narrow', 'medium', 'wide'];
              const next = order[(order.indexOf(prefs.width) + 1) % order.length];
              persist({ ...prefs, width: next });
            }}
          >
            <MoveHorizontal className="h-4 w-4" />
          </ToolbarButton>

          <Divider />

          <ToolbarButton label="Light theme" active={prefs.theme === 'light'} onClick={() => persist({ ...prefs, theme: 'light' })}>
            <Sun className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton label="Sepia theme" active={prefs.theme === 'sepia'} onClick={() => persist({ ...prefs, theme: 'sepia' })}>
            <Coffee className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton label="Dark theme" active={prefs.theme === 'dark'} onClick={() => persist({ ...prefs, theme: 'dark' })}>
            <Moon className="h-4 w-4" />
          </ToolbarButton>

          <Divider />

          {toc.length > 0 && (
            <ToolbarButton label="Table of contents" active={showToc} onClick={() => setShowToc((s) => !s)}>
              <BookOpenText className="h-4 w-4" />
            </ToolbarButton>
          )}
          <ToolbarButton label="Toggle fullscreen" onClick={toggleFullscreen}>
            <Maximize className="h-4 w-4" />
          </ToolbarButton>
        </div>

        <button
          ref={closeButtonRef}
          onClick={onClose}
          className="flex items-center gap-1.5 rounded-full border border-current/15 px-4 py-2 text-sm transition-colors hover:border-gold hover:text-gold-dark"
        >
          <X className="h-4 w-4" />
          Exit reader
        </button>
      </div>

      <div className="relative flex-1 overflow-hidden">
        {/* TOC panel */}
        {showToc && toc.length > 0 && (
          <div className="absolute left-0 top-0 z-10 h-full w-72 overflow-y-auto border-r border-current/10 bg-inherit p-6">
            <p className="mb-4 text-xs font-medium uppercase tracking-widest opacity-50">In this article</p>
            <nav className="space-y-1">
              {toc.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToHeading(item.id)}
                  className={`block w-full rounded-md px-3 py-2 text-left text-sm transition-colors ${
                    item.depth === 3 ? 'pl-6' : ''
                  } ${activeId === item.id ? 'bg-gold/15 text-gold-dark' : 'opacity-70 hover:opacity-100'}`}
                >
                  {item.text}
                </button>
              ))}
            </nav>
          </div>
        )}

        <div ref={scrollRef} className="reader-scroll h-full overflow-y-auto px-6 py-12 sm:px-12">
          <div className="mx-auto" style={{ maxWidth: WIDTH_PX[prefs.width] }}>
            <h1 className="font-serif text-3xl leading-tight sm:text-4xl">{title}</h1>
            <div
              style={{
                fontSize: `${prefs.fontSize}px`,
                lineHeight: LINE_HEIGHT[prefs.lineSpacing],
                fontFamily: prefs.fontFamily === 'serif' ? 'var(--font-serif)' : 'var(--font-sans)',
              }}
              className="mt-8"
            >
              <Markdown content={content} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ToolbarButton({
  children,
  label,
  onClick,
  active,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      aria-pressed={active}
      title={label}
      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors ${
        active ? 'bg-gold/20 text-gold-dark' : 'hover:bg-current/10'
      }`}
    >
      {children}
    </button>
  );
}

function Divider() {
  return <span className="mx-1 h-5 w-px shrink-0 bg-current/10" />;
}
