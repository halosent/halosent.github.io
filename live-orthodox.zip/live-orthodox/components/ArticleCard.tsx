import Link from 'next/link';
import { Clock, ArrowUpRight } from 'lucide-react';
import type { Article } from '@/lib/types';

function formatDate(date: string) {
  if (!date) return '';
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export default function ArticleCard({ article }: { article: Article }) {
  return (
    <Link
      href={`/articles/${article.slug}/`}
      className="group relative flex flex-col rounded-xl border border-line bg-paper p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold/40 hover:shadow-[0_12px_32px_-16px_rgba(200,169,106,0.35)]"
    >
      <div className="flex items-center justify-between">
        <span className="rounded-full border border-gold/30 bg-gold/[0.07] px-3 py-1 text-xs font-medium tracking-wide text-gold-dark">
          {article.category}
        </span>
        <ArrowUpRight className="h-4 w-4 text-ink/30 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-gold-dark" />
      </div>

      <h3 className="mt-4 font-serif text-xl leading-snug text-ink transition-colors group-hover:text-gold-dark">
        {article.title}
      </h3>
      <p className="mt-2.5 line-clamp-3 text-sm leading-relaxed text-ink/60">{article.description}</p>

      <div className="mt-5 flex items-center gap-3 border-t border-line pt-4 text-xs text-ink/45">
        <span>{article.author}</span>
        <span aria-hidden="true">·</span>
        <span>{formatDate(article.date)}</span>
        <span aria-hidden="true">·</span>
        <span className="flex items-center gap-1">
          <Clock className="h-3 w-3" strokeWidth={1.75} />
          {article.readingTime}
        </span>
      </div>
    </Link>
  );
}
