'use client';

import { useMemo, useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Search, SlidersHorizontal } from 'lucide-react';
import ArticleCard from '@/components/ArticleCard';
import type { Article } from '@/lib/types';
import { CATEGORIES } from '@/lib/types';

const PAGE_SIZE = 6;
type SortKey = 'newest' | 'oldest' | 'title';

export default function ArticlesExplorer({ articles }: { articles: Article[] }) {
  const searchParams = useSearchParams();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<string>('All');
  const [sort, setSort] = useState<SortKey>('newest');
  const [page, setPage] = useState(1);

  useEffect(() => {
    const fromUrl = searchParams?.get('category');
    if (fromUrl && CATEGORIES.includes(fromUrl)) setCategory(fromUrl);
  }, [searchParams]);

  const allTags = useMemo(() => {
    const set = new Set<string>();
    articles.forEach((a) => a.tags.forEach((t) => set.add(t)));
    return Array.from(set).sort();
  }, [articles]);
  const [tag, setTag] = useState<string>('All');

  const filtered = useMemo(() => {
    let result = articles;
    if (category !== 'All') result = result.filter((a) => a.category === category);
    if (tag !== 'All') result = result.filter((a) => a.tags.includes(tag));
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      result = result.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.description.toLowerCase().includes(q) ||
          a.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    const sorted = [...result];
    if (sort === 'newest') sorted.sort((a, b) => (a.date < b.date ? 1 : -1));
    if (sort === 'oldest') sorted.sort((a, b) => (a.date > b.date ? 1 : -1));
    if (sort === 'title') sorted.sort((a, b) => a.title.localeCompare(b.title));
    return sorted;
  }, [articles, category, tag, query, sort]);

  useEffect(() => setPage(1), [category, tag, query, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  return (
    <div>
      {/* Controls */}
      <div className="flex flex-col gap-4 rounded-xl border border-line bg-paper p-5 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search articles by title, summary, or tag…"
            className="w-full rounded-lg border border-line bg-canvas py-2.5 pl-9 pr-3 text-sm text-ink placeholder:text-ink/40 focus:border-gold/50 focus:outline-none"
            aria-label="Search articles"
          />
        </div>

        <div className="flex items-center gap-2">
          <SlidersHorizontal className="h-4 w-4 text-ink/40" />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded-lg border border-line bg-canvas px-3 py-2.5 text-sm text-ink focus:border-gold/50 focus:outline-none"
            aria-label="Filter by category"
          >
            <option value="All">All categories</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            value={tag}
            onChange={(e) => setTag(e.target.value)}
            className="rounded-lg border border-line bg-canvas px-3 py-2.5 text-sm text-ink focus:border-gold/50 focus:outline-none"
            aria-label="Filter by tag"
          >
            <option value="All">All tags</option>
            {allTags.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="rounded-lg border border-line bg-canvas px-3 py-2.5 text-sm text-ink focus:border-gold/50 focus:outline-none"
            aria-label="Sort articles"
          >
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
            <option value="title">Title A–Z</option>
          </select>
        </div>
      </div>

      <p className="mt-4 text-sm text-ink/50">
        {filtered.length} article{filtered.length === 1 ? '' : 's'} found
      </p>

      {/* Results */}
      {pageItems.length > 0 ? (
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {pageItems.map((a) => (
            <ArticleCard key={a.slug} article={a} />
          ))}
        </div>
      ) : (
        <div className="mt-10 rounded-xl border border-dashed border-line bg-paper px-6 py-16 text-center">
          <p className="text-ink/60">No articles match your search.</p>
          <p className="mt-1 text-sm text-ink/40">Try a different keyword, or clear the category and tag filters.</p>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-10 flex items-center justify-center gap-2">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button
              key={i}
              onClick={() => setPage(i + 1)}
              className={`h-9 w-9 rounded-full text-sm transition-colors ${
                page === i + 1 ? 'bg-ink text-paper' : 'border border-line text-ink/60 hover:border-gold/50'
              }`}
              aria-current={page === i + 1 ? 'page' : undefined}
              aria-label={`Page ${i + 1}`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
