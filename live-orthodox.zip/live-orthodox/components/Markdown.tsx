'use client';

import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeSlug from 'rehype-slug';
import rehypeAutolinkHeadings from 'rehype-autolink-headings';

export default function Markdown({ content }: { content: string }) {
  return (
    <div className="prose-orthodox prose prose-neutral max-w-none prose-headings:font-serif prose-headings:font-semibold prose-a:text-gold-dark prose-a:no-underline hover:prose-a:underline prose-strong:text-inherit">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeSlug, [rehypeAutolinkHeadings, { behavior: 'wrap' }]]}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
