'use client';

type Variant = 'home' | 'articles' | 'contradictions' | 'about';

/**
 * Ambient, low-opacity animated backgrounds. Pure CSS transforms/opacity only
 * (no layout properties) so they stay smooth and respect prefers-reduced-motion
 * via the global stylesheet, which collapses all animation durations to ~0.
 */
export default function AnimatedBackground({ variant = 'home' }: { variant?: Variant }) {
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* Base wash */}
      <div className="absolute inset-0 bg-canvas" />

      {variant === 'home' && (
        <>
          <div
            className="aurora-blob absolute -top-32 left-[8%] h-[32rem] w-[32rem] rounded-full bg-gold/20 animate-aurora"
            style={{ animationDelay: '0s' }}
          />
          <div
            className="aurora-blob absolute top-1/3 right-[4%] h-[28rem] w-[28rem] rounded-full bg-gold/10 animate-aurora-slow"
          />
          <div className="aurora-blob absolute bottom-0 left-1/4 h-[24rem] w-[24rem] rounded-full bg-gold/10 animate-aurora" style={{ animationDelay: '4s' }} />
          <FloatingParticles count={16} />
          <div className="absolute inset-0 motif-cross opacity-[0.04]" />
        </>
      )}

      {variant === 'articles' && (
        <>
          <div className="absolute inset-0 motif-cross opacity-[0.025]" />
          <div className="aurora-blob absolute top-0 right-0 h-[26rem] w-[26rem] rounded-full bg-gold/8 animate-aurora-slow" />
        </>
      )}

      {variant === 'contradictions' && (
        <>
          <GeometricGrid />
          <div className="aurora-blob absolute top-1/4 left-1/3 h-[22rem] w-[22rem] rounded-full bg-gold/10 animate-aurora-slow" />
        </>
      )}

      {variant === 'about' && (
        <>
          <div className="aurora-blob absolute -top-20 left-1/2 h-[30rem] w-[30rem] -translate-x-1/2 rounded-full bg-gold/12 animate-aurora" />
          <div className="absolute inset-0 motif-cross opacity-[0.03]" />
        </>
      )}

      {/* Soft top-of-page radial glow, present on every page for cohesion */}
      <div
        className="absolute left-1/2 top-0 h-[40rem] w-[70rem] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{
          background:
            'radial-gradient(closest-side, rgba(200,169,106,0.08), transparent 70%)',
        }}
      />
    </div>
  );
}

function FloatingParticles({ count = 12 }: { count?: number }) {
  const particles = Array.from({ length: count });
  return (
    <div className="absolute inset-0">
      {particles.map((_, i) => {
        const left = (i * 137.5) % 100; // golden-angle distribution, deterministic (SSR-safe)
        const top = (i * 71.3) % 100;
        const size = 2 + (i % 4);
        const duration = 18 + (i % 6) * 4;
        const delay = (i % 5) * 1.6;
        return (
          <span
            key={i}
            className="absolute rounded-full bg-gold/40 animate-drift"
            style={{
              left: `${left}%`,
              top: `${top}%`,
              width: size,
              height: size,
              animationDuration: `${duration}s`,
              animationDelay: `${delay}s`,
            }}
          />
        );
      })}
    </div>
  );
}

function GeometricGrid() {
  // A slow, elegant moving grid of interlocking Byzantine-inspired diamonds.
  return (
    <div
      className="absolute inset-0 opacity-[0.05] animate-drift"
      style={{
        backgroundImage:
          "linear-gradient(45deg, #C8A96A 1px, transparent 1px), linear-gradient(-45deg, #C8A96A 1px, transparent 1px)",
        backgroundSize: '64px 64px',
      }}
    />
  );
}
