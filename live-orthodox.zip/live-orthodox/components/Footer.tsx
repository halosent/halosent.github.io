import Link from 'next/link';
import { Cross, Mail } from 'lucide-react';
import { NAV_LINKS, SITE } from '@/lib/site';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative border-t border-line bg-paper">
      <div className="mx-auto max-w-6xl px-6 py-14">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2">
              <Cross className="h-5 w-5 text-gold" strokeWidth={1.5} />
              <span className="font-serif text-lg text-ink">Live Orthodox</span>
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-ink/60">
              {SITE.tagline}
            </p>
          </div>

          <div>
            <h3 className="text-sm font-medium tracking-wide text-ink/80">Navigate</h3>
            <ul className="mt-4 space-y-2.5">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-ink/60 transition-colors hover:text-gold-dark">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-medium tracking-wide text-ink/80">Contact</h3>
            <ul className="mt-4 space-y-2.5">
              <li>
                <a
                  href="mailto:contact@liveorthodox.org"
                  className="flex items-center gap-2 text-sm text-ink/60 transition-colors hover:text-gold-dark"
                >
                  <Mail className="h-3.5 w-3.5" strokeWidth={1.75} />
                  contact@liveorthodox.org
                </a>
              </li>
              <li>
                <Link href="/about/" className="text-sm text-ink/60 transition-colors hover:text-gold-dark">
                  About Live Orthodox
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-line pt-6 text-xs text-ink/50 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} Live Orthodox — Owned and maintained by <span className="text-ink/70">Unified</span>. All rights reserved.
          </p>
          <p>All content, ownership, and credits belong to Unified.</p>
        </div>
      </div>
    </footer>
  );
}
